package Treassure;

public class Gold {
}
