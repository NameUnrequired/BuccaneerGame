package Treassure;

public class Rum {
}
