package Treassure;

public class Ruby {
}
