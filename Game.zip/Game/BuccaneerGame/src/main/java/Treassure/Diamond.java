package Treassure;

public class Diamond {
}
