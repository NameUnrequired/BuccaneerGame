package Board;

public class Trading {
}
