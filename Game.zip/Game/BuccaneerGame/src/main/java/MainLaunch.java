import GUI.Main;
import javafx.application.Application;

public class MainLaunch {

    public static void main(final String[] args) {
        Application.launch(Main.class, args);
    }
}
